# Photino.Vue Hello World Sample

To build UI and run Photino in one command execute the following in a terminal.

```sh
# From inside root folder execute:
# `npm run build` will update the
# wwwroot folder after build is complete. 
cd UserInterface && npm run build && cd .. && dotnet run
```
