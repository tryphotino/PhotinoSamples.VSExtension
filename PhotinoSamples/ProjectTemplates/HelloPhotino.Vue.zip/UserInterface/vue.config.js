module.exports = {
    publicPath: "",
    outputDir: "../wwwroot"
}