import React from 'react';
import './App.css';
import ThreeContainer from './components/ThreeContainer';

function App() {
  return (
    <div>
      <ThreeContainer />
    </div>
  );
}

export default App;
